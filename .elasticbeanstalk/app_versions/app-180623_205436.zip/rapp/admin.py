from django.contrib import admin
from rapp.models import Authors,Publishers,Ebooks,UserP,Subscribers,Category,Usercart,Wishlist,Dashboard,Transactions,Notes,Lastpage,Uploaded


admin.site.register(Authors)
admin.site.register(Publishers)
admin.site.register(Ebooks)
admin.site.register(UserP)
admin.site.register(Subscribers)
admin.site.register(Category)
admin.site.register(Usercart)
admin.site.register(Wishlist)
admin.site.register(Dashboard)
admin.site.register(Transactions)
admin.site.register(Notes)
admin.site.register(Lastpage)
admin.site.register(Uploaded)
