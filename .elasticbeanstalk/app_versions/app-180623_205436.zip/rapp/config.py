SALT = 'kbkmIDzeF8'
KEY = 'TmzFTl5D'